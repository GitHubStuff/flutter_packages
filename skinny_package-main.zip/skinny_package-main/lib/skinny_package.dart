library skinny_package;
