# widgets 8-Mar-2021

Minimal Flutter App

## Getting Started

This project is a starting point for a Flutter application.
