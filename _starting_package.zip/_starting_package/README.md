# empty_pckage

This is an example project that is a good framework for an app

- It uses flutter_bloc

## Getting Started
