# empty_package

This is a template kit (with example) to create a Flutter Package.

The template project is a good foundation for creating packages that uses with BLoC and Modular programming patterns.

## Useage

The 'example' directory is an app that includes:

- Usage of [flutter_block](https://pub.dev/packages/flutter_bloc)

- Usage of [flutter_modular](https://pub.dev/packages/flutter_modular)

- Localizations using [intl](https://pub.dev/packages/intl)

- User settable Light/Dark mode using [ThemeManager](https://github.com/GitHubStuff/theme_manager) {Tap the light-bulb in the upper right corner}

## Final note

Be kind to each other!
