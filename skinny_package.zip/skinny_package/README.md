# empty_pckage

Template for Flutter package project.

## Getting Started
